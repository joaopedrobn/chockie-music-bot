from queue import Queue

class SongQueue(Queue):
    def __init__(self):
        super().__init__()