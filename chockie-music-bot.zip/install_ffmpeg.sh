#!/bin/bash
set -e

# Baixar e instalar ffmpeg
apt-get update
apt-get install -y ffmpeg